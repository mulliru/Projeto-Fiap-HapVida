package br.com.hapvida.forms;

public interface DisplayForms {

	public void exibir();
}
