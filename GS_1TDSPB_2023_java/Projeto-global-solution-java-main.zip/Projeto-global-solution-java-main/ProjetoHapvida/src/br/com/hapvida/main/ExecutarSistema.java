package br.com.hapvida.main;

import br.com.hapvida.forms.DisplayMenu;

public class ExecutarSistema {

	public static void main(String[] args) {
		DisplayMenu display = new DisplayMenu();
		display.exibir();
	}

}
